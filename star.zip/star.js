import { starships } from './assets/starships.js';

console.log(starships)
//console.log(starships[0].name);

const shipContainer = document.querySelector('#container')
//const statsContainer = document.querySelector('#sContainer')
// var count = 0
// var i = 0
// while (i <= 25) {
//     console.log(starships[count].name)
//     count++
//     i++
// }


starships.forEach(starship => {
let fig = document.createElement('figure')
let cap = document.createElement('figcaption')
let img = document.createElement('img')
img.src = `/assets/simg/${starship.name}.png`
cap.textContent = starship.name
fig.appendChild(img)
fig.appendChild(cap)
shipContainer.appendChild(fig)
//console.log(imgName)
    
});


starships.forEach(starship => {
let back = document.createElement('div')
let shipName = document.createElement('h2')
let shipModel = document.createElement('p')
let shipClass = document.createElement('p')
let shipCrew = document.createElement('p')
let shipDrive = document.createElement('p')
shipName.textContent = `${starship.name}`
shipModel.textContent = `Model: ${starship.model}`
shipClass.textContent = `Class: ${starship.starship_class}`
shipCrew.textContent = `Crew: ${starship.crew}`
shipDrive.textContent = `Hyperdrive rating: ${starship.hyperdrive_rating}`
back.appendChild(shipName)
back.appendChild(shipModel)
back.appendChild(shipClass)
back.appendChild(shipCrew)
back.appendChild(shipDrive)
//shipContainer.appendChild(statsContainer)
//console.log(statsContainer)
    });

//console.log(starships.name)


    // let statsList = document.createElement('backList')
    // // console.log(stats)
    // statsList.appendChild(stats)

 
var flip = document.querySelector('figure');
flip.addEventListener( 'click', function() {
    flip.classList.toggle('flipped');
    
});